var goods = [
  {
    name: 'iPhone 12',
    choose: 0,
  },
  {
    name: '荣耀X30',
    choose: 1,
  },
  {
    name: 'Redmi Note 11',
    choose: 3,
  },
  {
    name: 'OPPO K9x',
    choose: 0,
  },
  {
    name: '华为Nova10pro',
    choose: 1,
  },
];
